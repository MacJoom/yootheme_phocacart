> :warning: **Use this with care — provide access only to trusted user roles**. 

# Yootheme PhocaCart Bridge

This is a bridge of [YooThemePro (YTP) Page Builder](https://yootheme.com/page-builder) with [PhocaCart](https://phoca.cz). It provides a front-end, 'drag and drop' layout builder for PhocaCart Entities, such as Products and Categories, which are loaded as Dynamic Content [custom sources](https://yootheme.com/support/yootheme-pro/joomla/developers-sources) into YTP. It uses PhocaCart API, and integrates with Dynaimic Content features including filtering and sorting by field, filtering by category & image URLs.

It was originally developed by [Deepak Srivastava](https://github.com/deepak-srivastava/) of [Mountev](https://mountev.co.uk/), with the support of [Joshua Gowans](https://lab.civicrm.org/josh) and [Nicol](https://lab.civicrm.org/nicol) Wistreich ([Vingle](https://github.com/vingle)) for CiviCRM
and was adapted for PhocaCart by Martin Kopp (https://infotech.ch)

## Installation

1. Install the YOOtheme Pro template (Joomla!).

2. Install this child template via **System → Install → Extensions**, uploading the
   `yootheme_phocacart-x.y.z.zip` package (it ships a `templateDetails.xml` manifest, so it
   installs, updates, and uninstalls like any Joomla extension). Alternatively, copy the
   `yootheme_phocacart` folder into `/templates/` manually.

3. Activate the child in YOOtheme — in the Customizer, **Settings → Child Theme → phocacart**.
   (Under the hood this sets `child_theme = phocacart` on the active YOOtheme template style,
   which is how the parent `yootheme` template loads this folder.)

4. Follow YTP's [documentation for Dynamic Content](https://yootheme.com/support/yootheme-pro/joomla/dynamic-content),
   selecting the PhocaCart Products / Categories entries as Custom Sources.

> This template has no `index.php` of its own — it is a YOOtheme child that renders through the
> parent `yootheme` template. Do **not** assign its auto-created template style directly; it is
> only meant to be loaded via the Child Theme setting above.

> **It is recommended to use this only on test/dev sites until you are comfortable with, and understand, how it works**

## Building the install package

Zip the **contents** of the `yootheme_phocacart` folder so that `templateDetails.xml` sits at
the **root** of the archive (not nested inside a `yootheme_phocacart/` sub-folder), using
forward-slash paths. Exclude VCS files (`.gitattributes`, etc.).

## Changelog

### 2026-07-31 — Installable extension

- Added a `templateDetails.xml` manifest (`type="template"`, `client="site"`,
  `element="yootheme_phocacart"`), so the template can now be installed, updated and
  uninstalled through Joomla's Extension Manager instead of copying files manually. The load
  mechanism is unchanged — it is still activated via the YOOtheme Child Theme setting
  (`child_theme = phocacart`).

### 2026-07-31 — Joomla 5 / YOOtheme Pro 5 compatibility

Fixed dynamic-content sources rendering empty after the site was upgraded to
**Joomla 5 + YOOtheme Pro 5.0.38**.

- **Case-sensitive GraphQL field names (the actual render blocker).** Renamed the registered
  query fields from `Phocacartproducts` / `Phocacartcategories` to lowercase
  `phocacartproducts` / `phocacartcategories` to match the names saved in existing layouts.
  YOOtheme 4 tolerated the case mismatch; YOOtheme 5 does not, so the resolvers were never
  called and the elements stayed empty.
- **Namespaced classes (Joomla 6 forward-compat).** Replaced `JText` / `JRoute` / `JTable`
  with `Joomla\CMS\Language\Text` / `Router\Route` / `Table\Table` and removed dead
  `jimport()` calls. These `J*` aliases still work today via the `plg_behaviour_compat`
  plugin but are removed in **Joomla 6.0**, so this keeps the template working through that
  upgrade. (This was *not* the cause of the empty pages.)
- **`catid_multiple` warning.** Initialised `$p['catid_multiple']` to an empty array before
  the category conditional in the products resolver, so selecting the "– ANY –" category no
  longer emits an `Undefined array key "catid_multiple"` warning (and passes a correct array
  type to `PhocacartProduct::getProducts()`).

See [`FIXES.md`](FIXES.md) for full details.
