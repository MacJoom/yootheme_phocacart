# yootheme_phocacart — YOOtheme Pro 4 → 5 Migration Fixes

## Summary

The `yootheme_phocacart` child template registers **PhocaCart products and categories**
as YOOtheme *Dynamic Content* sources. It worked on YOOtheme Pro 4.5, but after the site
was upgraded to **Joomla 5.4.7 + YOOtheme Pro 5.0.38**, builder elements bound to these
sources rendered **empty** — no products, no categories.

There was **one render blocker** (the GraphQL field-name case, below) plus **one
forward-compatibility hardening** (the `J*` classes). Fixing the field name is what made the
dynamic content appear again; the class change matters for the future Joomla 6 upgrade.

All changes are contained inside `templates/yootheme_phocacart/`. No Joomla core files and
no parent `templates/yootheme` files were modified.

---

## Item 1 — Legacy `J*` classes (forward-compat, **not** the render blocker)

Joomla 5 removed `libraries/classmap.php`. The legacy `J*` aliases (`JText`, `JRoute`,
`JTable`, …) now only exist when the **Behaviour – Backward Compatibility** plugin
(`plg_behaviour_compat`) is enabled — which it is on this site — so the template's `J*`
calls actually **kept working at render time**. They were *not* what broke the pages.

However, those aliases are registered with a removal version of **`6.0`** — i.e. they are
**dropped in Joomla 6.0**. So the code was migrated to the real namespaced classes to survive
that upgrade (and to allow eventually disabling the deprecated compat plugin):

| Legacy call | Namespaced replacement |
| --- | --- |
| `JText::_()`             | `Joomla\CMS\Language\Text::_()` |
| `JRoute::_()`            | `Joomla\CMS\Router\Route::_()` |
| `JTable::addIncludePath()` | `Joomla\CMS\Table\Table::addIncludePath()` |

`JLoader` and `jimport()` still exist in Joomla 5, so those were left as-is.

## Item 2 — GraphQL source field-name case mismatch (**the actual render blocker**)

YOOtheme Dynamic Content is resolved through GraphQL, and **GraphQL field names are
case-sensitive**. The saved article layouts query the sources in **lowercase**:

```json
"source": { "query": { "name": "phocacartproducts",   … } }
"source": { "query": { "name": "phocacartcategories", … } }
```

…but the code registered the query fields **capitalized** (`Phocacartproducts` /
`Phocacartcategories`). YOOtheme Pro 4 tolerated the mismatch; **YOOtheme Pro 5 does not** —
the field lookup failed, so the resolver was **never called** and the element stayed empty.

This was the actual reason the dynamic content did not load its data.

---

## Changes

### `modules/phoca/src/PhocacartYTUtils.php`
- Added `use Joomla\CMS\Language\Text;` and `use Joomla\CMS\Table\Table;`.
- `JTable::addIncludePath(...)` → `Table::addIncludePath(...)`.
- `JText::_(...)` → `Text::_(...)` (both field-label loops).
- Removed the dead `jimport('joomla.application.component.controller')` call.

### `modules/phoca/src/PhocacartProductsQueryType.php`
- Added `use Joomla\CMS\Router\Route;`.
- `JRoute::_(...)` → `Route::_(...)`.
- Guarded the `DS` constant define; removed dead filesystem `jimport()` calls.
- **Renamed the query field `Phocacartproducts` → `phocacartproducts`** (matches the layouts).

### `modules/phoca/src/PhocacartCategoriesQueryType.php`
- Added `use Joomla\CMS\Router\Route;`.
- `JRoute::_(...)` → `Route::_(...)`.
- Guarded the `DS` constant define; removed dead filesystem `jimport()` calls.
- **Renamed the query field `Phocacartcategories` → `phocacartcategories`** (matches the layouts).

> The GraphQL **object type** names (`PhocacartProduct`, `PhocacartCategory`) were left
> unchanged — only the **query field** names needed to match the saved layouts.

---

## How it was verified

- Booting the data layer directly confirmed it was always healthy:
  `PhocacartCategory::getCategories()` returns 21 rows and the type `config()` builds fine.
- `error_log()` probes on `config.php`, `SourceListener::initSource`, and each resolver
  (temporary, since removed) confirmed on the live frontend (**http://bsm.test:8081**):
  - the child template loads and `initSource` registers the sources, and
  - after the case fix, the resolvers fire — e.g. `categories RETURN rows=21` — and the
    pages render the categories/products with images.

---

## Notes

- **After changing a source, save the YOOtheme Customizer once** — YOOtheme compiles its
  builder/source schema into `templates/yootheme/cache/` and only rebuilds it there.
- Fixed a pre-existing latent quirk in `PhocacartProductsQueryType::resolve()`: selecting the
  "– ANY –" category (`0`) used to emit an `Undefined array key "catid_multiple"` PHP warning
  because `catid_multiple` was only set when a specific category was chosen, then read
  unconditionally. It is now initialised to an empty array before the conditional, which
  silences the warning and passes the correct array type to `PhocacartProduct::getProducts()`.
  Output was already correct; this removes the log noise and the type mismatch.

## Compatibility

The fixed template is intentionally version-portable:

- **Joomla 4, 5.x (incl. 5.3.3 and 5.4.7), and 6** — the namespaced `Text` / `Route` / `Table`
  classes exist natively since Joomla 3.8, so they work across all of these.
- **YOOtheme Pro 4.5 and 5** — the lowercase field names match what YOOtheme already saved in
  the layouts (they were created under 4.5), so they resolve on both.
- **PhocaCart 4 and 5** — no PhocaCart API calls were changed; `catid_multiple` now passes an
  empty array (PhocaCart's own default) instead of `null`.

The real gating factor is **Joomla ≥ 4** (the original code already used
`Factory::getContainer()->get('DatabaseDriver')`, a Joomla 4 API).

> **Joomla 6 note:** the `J*` aliases this template used to rely on come from the
> `plg_behaviour_compat` plugin and are flagged for removal in **Joomla 6.0**. The namespaced
> migration above means the template is already Joomla-6-ready and no longer depends on that
> deprecated compat plugin.

## Environment reference

- Currently: Joomla **5.4.7** (dev) / **5.3.3** (target to update first), YOOtheme Pro **5.0.38**,
  PHP **8.3** (Apache mod_php, opcache off, Xdebug on).
- `plg_behaviour_compat` (Behaviour – Backward Compatibility) is **enabled**, which is why the
  original `J*` calls kept working before this migration.
- Frontend served on **port 8081** (`http://bsm.test:8081`).
- Home template style #16 "BSM Yootheme" carries `child_theme = phocacart`, which is how the
  legacy child template is loaded.
